import 'package:finanzas_verdes/app/config/Global.dart';
import 'package:finanzas_verdes/controllers/ClientController.dart';
import 'package:finanzas_verdes/main.dart';
import 'package:finanzas_verdes/models/api/fveApi.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

class Procesofveasesor extends StatefulWidget {
  const Procesofveasesor({super.key});

  @override
  State<Procesofveasesor> createState() => _ProcesofveasesorState();
}

class _ProcesofveasesorState extends State<Procesofveasesor> {
  final ClientController client = Get.find<ClientController>();
  bool loading = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _refresh());
  }

  Future<void> _refresh() async {
    final id = int.tryParse(client.ProcesoFve['id_proceso']?.toString() ?? '');
    if (id == null || loading) return;
    setState(() => loading = true);
    try {
      final proceso = await obtenerProcesoFveApi(idProceso: id);
      client.setProcesoFve(proceso);
    } catch (e) {
      if (mounted) {
        Get.snackbar(
          'No se pudo cargar el proceso',
          e.toString(),
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: Colors.red.shade700,
          colorText: Colors.white,
        );
      }
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Widget _card({required String title, required Widget child}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Global.container,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Global.text.withOpacity(0.09)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: GoogleFonts.poppins(
            color: Global.text,
            fontWeight: FontWeight.w700,
            fontSize: 16,
          )),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }

  Widget _info(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 160,
            child: Text(label, style: GoogleFonts.poppins(
              color: Global.textSecondary, fontSize: 12)),
          ),
          Expanded(child: Text(value, style: GoogleFonts.poppins(
            color: Global.text, fontSize: 12, fontWeight: FontWeight.w600))),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      final p = client.ProcesoFve;
      final id = p['id_proceso']?.toString() ?? '-';
      final estado = p['estado']?.toString() ?? '-';

      return Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
            decoration: BoxDecoration(
              color: Global.container,
              border: Border(bottom: BorderSide(
                color: Global.text.withOpacity(0.08))),
            ),
            child: Row(children: [
              IconButton(
                onPressed: controller.backPage,
                icon: Icon(Icons.arrow_back_rounded, color: Global.text),
                tooltip: 'Volver al diagn\u00f3stico',
              ),
              const SizedBox(width: 10),
              Expanded(child: Text(
                'Proceso FVE #$id',
                style: GoogleFonts.poppins(color: Global.text,
                    fontWeight: FontWeight.w700, fontSize: 18),
              )),
              IconButton(
                onPressed: loading ? null : _refresh,
                icon: const Icon(Icons.refresh_rounded),
                tooltip: 'Actualizar',
              ),
            ]),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Center(child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 880),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _card(
                      title: 'Proceso de negociaci\u00f3n',
                      child: Column(children: [
                        _info('Estado', estado.replaceAll('_', ' ')),
                        _info('Diagn\u00f3stico origen',
                            '#${p['id_diagnostico'] ?? '-'}'),
                        _info('Empresa',
                            p['nombre_mipyme']?.toString() ??
                            client.Client['mipyme']?['nombre_mipyme']?.toString() ?? '-'),
                        _info('Paso actual', '${p['paso_actual'] ?? 2} de 9'),
                        _info('Creado por', '#${p['created_by'] ?? '-'}'),
                      ]),
                    ),
                    const SizedBox(height: 18),
                    _card(
                      title: 'Siguiente paso: revisar alternativas',
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'El proceso ya est\u00e1 guardado en PostgreSQL. '
                            'En la siguiente entrega conectaremos el selector de '
                            'productos y la negociaci\u00f3n de cantidades, sin '
                            'modificar el diagn\u00f3stico original.',
                            style: GoogleFonts.poppins(
                              color: Global.textSecondary, fontSize: 13),
                          ),
                          const SizedBox(height: 16),
                          OutlinedButton.icon(
                            onPressed: controller.backPage,
                            icon: const Icon(Icons.visibility_rounded),
                            label: const Text('Volver a revisar el diagn\u00f3stico'),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    if (loading) const LinearProgressIndicator(),
                    Text(
                      'Entrega 00: inicio de proceso. No genera ni acepta '
                      'propuestas todav\u00eda.',
                      style: GoogleFonts.poppins(
                        fontSize: 11, color: Global.textSecondary),
                    ),
                  ],
                ),
              )),
            ),
          ),
        ],
      );
    });
  }
}
