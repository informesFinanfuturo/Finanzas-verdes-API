import 'dart:async';
import 'dart:convert';

import 'package:finanzas_verdes/app/config/Global.dart';
import 'package:finanzas_verdes/app/routes/routeNames.dart';
import 'package:finanzas_verdes/app/routes/subrutes/adminRoutes.dart';
import 'package:finanzas_verdes/app/routes/subrutes/asesorRoutes.dart';
import 'package:finanzas_verdes/app/routes/subrutes/clienteRoutes.dart';
import 'package:finanzas_verdes/app/routes/subrutes/proveedorRoutes.dart';
import 'package:finanzas_verdes/app/routes/subrutes/superadminRoutes.dart';
import 'package:finanzas_verdes/main.dart';
import 'package:finanzas_verdes/models/api/calendarioApi.dart';
import 'package:finanzas_verdes/views/admin/screens/homeAdmin.dart';
import 'package:finanzas_verdes/views/admin/screens/moreAdmin.dart';
import 'package:finanzas_verdes/views/admin/screens/proveedoresAdmin.dart';
import 'package:finanzas_verdes/views/admin/screens/rolsAdmin.dart';
import 'package:finanzas_verdes/views/admin/screens/usersAdmin.dart';
import 'package:finanzas_verdes/views/admin/users/editUserAdmin.dart';
import 'package:finanzas_verdes/views/admin/users/newUserAdmin.dart';
import 'package:finanzas_verdes/views/asesor/client/activo/editActivoAsesor.dart';
import 'package:finanzas_verdes/views/asesor/client/activo/newActivoAsesor.dart';
import 'package:finanzas_verdes/views/asesor/client/consumo/editConsumoAsesor.dart';
import 'package:finanzas_verdes/views/asesor/client/dashBoardClientAsesor.dart';
import 'package:finanzas_verdes/views/asesor/client/diagnostico/ViewDiagnosticoAsesor.dart';
import 'package:finanzas_verdes/views/asesor/client/fve/procesoFveAsesor.dart';
import 'package:finanzas_verdes/views/asesor/client/diagnostico/newDiagnosticoAsesor.dart';
import 'package:finanzas_verdes/views/asesor/client/editClientAsesor.dart';
import 'package:finanzas_verdes/views/asesor/client/mipyme/editMipymeAsesor.dart';
import 'package:finanzas_verdes/views/asesor/client/newClientAsesor.dart';
import 'package:finanzas_verdes/views/asesor/client/mipyme/newClientWithMipymeAsesor.dart';
import 'package:finanzas_verdes/views/asesor/client/plan_trabajo/editPlanTrabajoAsesor.dart';
import 'package:finanzas_verdes/views/asesor/client/plan_trabajo/newPlanTrabajoAsesor.dart';
import 'package:finanzas_verdes/views/asesor/client/plan_trabajo/viewPlanTrabajoAsesor.dart';
import 'package:finanzas_verdes/views/asesor/screens/clientsAsesor.dart';
import 'package:finanzas_verdes/views/asesor/screens/homeAsesor.dart';
import 'package:finanzas_verdes/views/asesor/screens/moreAsesor.dart';
import 'package:finanzas_verdes/views/cliente/screens/ActivosCliente.dart';
import 'package:finanzas_verdes/views/cliente/screens/ConsumosCliente.dart';
import 'package:finanzas_verdes/views/cliente/screens/DiagnosticosCliente.dart';
import 'package:finanzas_verdes/views/cliente/screens/Homecliente.dart';
import 'package:finanzas_verdes/views/cliente/screens/moreCliente.dart';
import 'package:finanzas_verdes/views/proveedor/catalogo/editCatalogoProveedor.dart';
import 'package:finanzas_verdes/views/proveedor/catalogo/newCatalogoProveedor.dart';
import 'package:finanzas_verdes/views/proveedor/screens/CatalogoProveedor.dart';
import 'package:finanzas_verdes/views/proveedor/screens/Homeproveedor.dart';
import 'package:finanzas_verdes/views/proveedor/screens/moreProveedor.dart';
import 'package:finanzas_verdes/views/superadmin/screens/homeAdmin.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:syncfusion_flutter_calendar/calendar.dart';

class Generalcontoller extends GetxController {
  // VARIABLES
  Timer? timer;
  final isDark = false.obs;
  final RxString page = ''.obs;
  final RxList<String> historyPages = <String>[].obs;
  bool _navigationInProgress = false;
  static const int _maxHistoryLength = 40;
  final calendario = [].obs;
  final agenda = [].obs;
  final pages = {
    // ADMINISTRADOR
    Adminroutes.home: Homeadmin(),
    Adminroutes.users: Usersadmin(),
    Adminroutes.newUser: Newuseradmin(),
    Adminroutes.more: Moreadmin(),
    Adminroutes.editUser: Edituseradmin(),
    Adminroutes.rols: Rolsadmin(),
    Adminroutes.homeProveedores: Proveedoresadmin(),

    // ASESOR
    AsesorRoutes.home: Homeasesor(),
    AsesorRoutes.more: Moreasesor(),
    AsesorRoutes.clients: Clientsasesor(),
    AsesorRoutes.newClient: Newclientasesor(),
    AsesorRoutes.newClientMipyme: Newclientwithmipymeasesor(),
    AsesorRoutes.editClient: Editclientasesor(),
    AsesorRoutes.dashBoardClient: Dashboardclientasesor(),
    AsesorRoutes.editMipyme: Editmipymeasesor(),
    AsesorRoutes.newActivo: Newactivoasesor(),
    AsesorRoutes.editActivo: Editactivoasesor(),
    AsesorRoutes.editConsumo: Editconsumoasesor(),
    AsesorRoutes.newDiagnostico: Newdiagnosticoasesor(),
    AsesorRoutes.viewDiagnostico: Viewdiagnosticoasesor(),
    AsesorRoutes.procesoFve: const Procesofveasesor(),
    AsesorRoutes.newPlanTrabajo: Newplantrabajoasesor(),
    AsesorRoutes.editPlanTrabajo: Editplantrabajoasesor(),
    AsesorRoutes.viewPlanTrabajo: Viewplantrabajoasesor(),

    // CLIENTE
    ClienteRoutes.home: Homecliente(),
    ClienteRoutes.more: Morecliente(),
    ClienteRoutes.activos: Activoscliente(),
    ClienteRoutes.consumos: Consumoscliente(),
    ClienteRoutes.diagnosticos: Diagnosticoscliente(),

    // PROVEEDOR
    ProveedorRoutes.home: Homeproveedor(),
    ProveedorRoutes.more: Moreproveedor(),
    ProveedorRoutes.catalogo: Catalogoproveedor(),
    ProveedorRoutes.newCatalogo: Newcatalogoproveedor(),
    ProveedorRoutes.editCatalogo: Editcatalogoproveedor(),

    // SUPER ADMIN
    SuperadminRoutes.home: Homesuperadmin(),
  }.obs;
  final user = {}.obs;
  final appointments = <Appointment>[].obs;

  final firstDate = DateTime.now().obs;
  final endDate = DateTime.now().obs;
  final hasUnsavedChanges = false.obs;

  // FUNCIONES
  void setSplash() {
    timer?.cancel();
    int seconds = 2;
    timer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (seconds > 0) {
        seconds--;
      } else {
        timer.cancel();
        initUser();
      }
    });
  }

  void toggleTheme() {
    isDark.value = !isDark.value;
  }


  Set<String> _allowedPagesForRole() {
    final role = (
        user["rol"]?["nombre_rol"] ?? ""
    ).toString().trim().toLowerCase();

    final adminRoutes = <String>{
      Adminroutes.home,
      Adminroutes.users,
      Adminroutes.newUser,
      Adminroutes.editUser,
      Adminroutes.more,
      Adminroutes.rols,
      Adminroutes.homeProveedores,
    };

    final asesorRoutes = <String>{
      AsesorRoutes.home,
      AsesorRoutes.more,
      AsesorRoutes.clients,
      AsesorRoutes.newClient,
      AsesorRoutes.newClientMipyme,
      AsesorRoutes.editClient,
      AsesorRoutes.dashBoardClient,
      AsesorRoutes.editMipyme,
      AsesorRoutes.newActivo,
      AsesorRoutes.editActivo,
      AsesorRoutes.editConsumo,
      AsesorRoutes.newDiagnostico,
      AsesorRoutes.viewDiagnostico,
      AsesorRoutes.procesoFve,
      AsesorRoutes.newPlanTrabajo,
      AsesorRoutes.editPlanTrabajo,
      AsesorRoutes.viewPlanTrabajo,
    };

    final clienteRoutes = <String>{
      ClienteRoutes.home,
      ClienteRoutes.more,
      ClienteRoutes.activos,
      ClienteRoutes.consumos,
      ClienteRoutes.diagnosticos,
    };

    final proveedorRoutes = <String>{
      ProveedorRoutes.home,
      ProveedorRoutes.more,
      ProveedorRoutes.catalogo,
      ProveedorRoutes.newCatalogo,
      ProveedorRoutes.editCatalogo,
    };

    switch (role) {
      case "administrador":
        return adminRoutes;

      case "asesor":
        return asesorRoutes;

      case "cliente":
        return clienteRoutes;

      case "proveedor":
        return proveedorRoutes;

      case "super administrador":
        return {
          SuperadminRoutes.home,
          ...adminRoutes,
        };

      default:
        return {};
    }
  }


  bool _isValidInternalPage(String route) {
    if (!pages.containsKey(route)) {
      debugPrint(
        "[NAV] Ruta inexistente: $route",
      );
      return false;
    }

    final allowed = _allowedPagesForRole();

    if (!allowed.contains(route)) {
      debugPrint(
        "[NAV] Acceso no permitido a: $route",
      );
      return false;
    }

    return true;
  }

  Future<bool> _confirmLeavePage() async {
    if (!hasUnsavedChanges.value) {
      return true;
    }

    final salir = await Get.dialog<bool>(
      AlertDialog(
        title: const Text(
          "Cambios sin guardar",
        ),
        content: const Text(
          "Tienes cambios sin guardar. "
              "¿Deseas salir de todas formas?",
        ),
        actions: [
          TextButton(
            onPressed: () {
              Get.back(result: false);
            },
            child: const Text(
              "Continuar editando",
            ),
          ),
          ElevatedButton(
            onPressed: () {
              Get.back(result: true);
            },
            child: const Text(
              "Salir",
            ),
          ),
        ],
      ),
      barrierDismissible: false,
    );

    // Si cancela, no se modifica ningún estado.
    if (salir != true) {
      return false;
    }

    return true;
  }

  void _pushHistory(String route) {
    if (route.isEmpty) {
      return;
    }

    if (!_isValidInternalPage(route)) {
      return;
    }

    // Evitar páginas consecutivas duplicadas.
    if (
    historyPages.isNotEmpty &&
        historyPages.last == route
    ) {
      return;
    }

    historyPages.add(route);

    // Limitar memoria del historial.
    if (historyPages.length > _maxHistoryLength) {
      historyPages.removeAt(0);
    }
  }

  Future<bool> goToPage(
      String route, {
        bool addToHistory = true,
      }) async {
    if (_navigationInProgress) {
      return false;
    }

    if (page.value == route) {
      return true;
    }

    if (!_isValidInternalPage(route)) {
      return false;
    }

    _navigationInProgress = true;

    try {
      final canLeave = await _confirmLeavePage();

      if (!canLeave) {
        return false;
      }

      final previousPage = page.value;

      if (
      addToHistory &&
          previousPage.isNotEmpty
      ) {
        _pushHistory(previousPage);
      }

      hasUnsavedChanges.value = false;

      page.value = route;

      debugPrint(
        "[NAV] $previousPage -> $route",
      );

      return true;
    } finally {
      _navigationInProgress = false;
    }
  }

  // ============================================================
  // COMPATIBILIDAD CON LLAMADAS EXISTENTES
  // ============================================================

  Future<bool> setPage(String route) {
    return goToPage(route);
  }

  // ============================================================
  // VOLVER A LA PÁGINA ANTERIOR
  // ============================================================

  Future<bool> backPage() async {
    if (_navigationInProgress) {
      return false;
    }

    _navigationInProgress = true;

    try {
      // No salir del dashboard desde su página raíz.
      if (historyPages.isEmpty) {
        debugPrint(
          "[NAV] Sin historial interno disponible",
        );
        return false;
      }

      // Comprobar cambios pendientes.
      final canLeave = await _confirmLeavePage();

      if (!canLeave) {
        return false;
      }

      // Descartar entradas inválidas o de otro rol.
      while (historyPages.isNotEmpty) {
        final previousPage = historyPages.removeLast();

        if (!_isValidInternalPage(previousPage)) {
          continue;
        }

        if (previousPage == page.value) {
          continue;
        }

        hasUnsavedChanges.value = false;
        page.value = previousPage;

        debugPrint(
          "[NAV] Regresando a $previousPage",
        );

        return true;
      }

      // No modificar la página actual.
      return false;
    } finally {
      _navigationInProgress = false;
    }
  }

  Future<bool> replacePage(String route) async {
    return goToPage(
      route,
      addToHistory: false,
    );
  }

  bool replacePageAfterSave(String route) {
    if (_navigationInProgress) {
      return false;
    }

    if (!_isValidInternalPage(route)) {
      return false;
    }

    hasUnsavedChanges.value = false;
    page.value = route;

    return true;
  }

  void resetNavigation({
    String? initialPage,
  }) {
    historyPages.clear();
    hasUnsavedChanges.value = false;
    _navigationInProgress = false;

    if (
    initialPage != null &&
        _isValidInternalPage(initialPage)
    ) {
      page.value = initialPage;
    } else {
      page.value = "";
    }
  }

  Future<bool> goHome(String route) async {
    if (_navigationInProgress) {
      return false;
    }

    if (!_isValidInternalPage(route)) {
      return false;
    }

    _navigationInProgress = true;

    try {
      final canLeave = await _confirmLeavePage();

      if (!canLeave) {
        return false;
      }

      historyPages.clear();
      hasUnsavedChanges.value = false;
      page.value = route;

      return true;
    } finally {
      _navigationInProgress = false;
    }
  }


  void setUser(Map item) {
    user.value = item;
  }

  Future<void> redirectToAndSave(
      Map userData,
      ) async {
    final box = GetStorage();

    // Guardar la información del usuario.
    await box.write("user", userData);

    // Actualizar el usuario en memoria.
    setUser(userData);

    // Determinar la ruta por rol.
    final role = (
        userData["rol"]?["nombre_rol"] ?? ""
    ).toString().trim().toLowerCase();

    String? destination;

    switch (role) {
      case "administrador":
        destination = Routes.dashboardAdmin;
        break;

      case "asesor":
        destination = Routes.dashboardAsesor;
        break;

      case "cliente":
        destination = Routes.dashboardCliente;
        break;

      case "proveedor":
        destination = Routes.dashboardProveedor;
        break;

      case "super administrador":
        destination = Routes.dashboardSuperAdmin;
        break;
    }

    if (destination == null) {
      debugPrint(
        "[AUTH] Rol no reconocido: $role",
      );

      Get.offAllNamed(Routes.login);
      return;
    }

    resetNavigation();
    Get.offAllNamed(destination);
  }

  void logOut() {
    resetNavigation();
    setUser({});
    final box = GetStorage();
    box.remove("user");
    box.remove("token");
    Get.offAllNamed(Routes.login);
  }

  Future<bool> requestLogOut() async {
    if (_navigationInProgress) {
      return false;
    }

    _navigationInProgress = true;

    try {
      final canLeave = await _confirmLeavePage();

      if (!canLeave) {
        return false;
      }
    } finally {
      _navigationInProgress = false;
    }

    logOut();

    return true;
  }

  void initUser() {
    final box = GetStorage();
    final userBox = box.read("user");
    if (userBox == null) {
      Get.offNamed(Routes.login);
    } else {
      setUser(userBox);
      redirectToAndSave(userBox);
    }
  }

  void setCalendario(List item) {
    calendario.value = item;
  }

  void setAgenda(List item) {
    agenda.value = item;
  }

  void setAppointments(List<Appointment> item) {
    appointments.value = item;
  }

  Future<void> loadRange(DateTime start, DateTime end) async {
    final agenda = await getClientsAgendaRangeApi(
      fechaInicio: start,
      fechaFin: end,
    );

    final appointments = agenda.map<Appointment>((item) {
      final fecha = DateTime.parse(item["fecha_hora"]);

      /*
     * Título o tipo principal del evento.
     * Cambia el orden si tu API utiliza
     * otro nombre de campo.
     */
      final String eventTitle = _firstValidAgendaText([
        item["titulo"],
        item["tipo_visita"],
        item["tipo"],
        item["motivo"],
        item["descripcion"],
        "Visita programada",
      ]);

      final String companyName = _firstValidAgendaText([
        item["nombre_mipyme"],
        item["nombre_usuario"],
        "Cliente sin empresa",
      ]);

      return Appointment(
        /*
       * Toda la información queda disponible
       * para el appointmentBuilder y los modales.
       */
        notes: jsonEncode(item),

        startTime: fecha,

        endTime: fecha.add(const Duration(hours: 2)),

        /*
       * Syncfusion utilizará el tipo del evento
       * como título principal.
       */
        subject: eventTitle,

        /*
       * Podemos aprovechar location para guardar
       * temporalmente el nombre de la empresa.
       */
        location: companyName,

        color: Global.primary,
      );
    }).toList();

    controller.setAppointments(appointments);
  }

  String _firstValidAgendaText(List<dynamic> values) {
    for (final value in values) {
      final text = value?.toString().trim() ?? "";

      if (text.isNotEmpty && text.toLowerCase() != "null") {
        return text;
      }
    }

    return "";
  }

  ThemeMode get themeMode => isDark.value ? ThemeMode.dark : ThemeMode.light;
  Map get Pages => pages.value;
  String get Page => page.value;
  Map get User => user.value;
  List get Calendario => calendario.value;
  List get Agenda => agenda.value;
  List<Appointment> get Appointments => appointments.value;

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    final brightness =
        SchedulerBinding.instance.platformDispatcher.platformBrightness;
    isDark.value = brightness == Brightness.dark;
    setSplash();
    final presente = DateTime.now();

    firstDate.value = DateTime(
      presente.year,
      presente.month,
      presente.day - (presente.weekday - 1),
    );

    endDate.value = DateTime(
      presente.year,
      presente.month,
      presente.day + (7 - presente.weekday),
    );
  }
}
