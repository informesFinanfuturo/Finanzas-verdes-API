'use strict';

const router = require('express').Router();
const requirePermissions = require('../middleware/requirePermissions');
const pool = require('../db');
const { createFveHandlers } = require('../controllers/fve.controller');
const { iniciarProceso, obtenerProceso, obtenerPorDiagnostico } = createFveHandlers(pool);

// Reuse current diagnostic permissions only for Entrega 00.
// Future releases can replace these with specific FVE permissions.
router.post('/procesos', requirePermissions(['Generar diagn\u00f3stico']), iniciarProceso);
router.get('/procesos/diagnostico/:idDiagnostico', requirePermissions(['Obtener diagn\u00f3sticos']), obtenerPorDiagnostico);
router.get('/procesos/:idProceso', requirePermissions(['Obtener diagn\u00f3sticos']), obtenerProceso);

module.exports = router;
