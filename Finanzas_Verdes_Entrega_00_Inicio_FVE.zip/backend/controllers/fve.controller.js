'use strict';

function parseId(value) {
  const id = Number(value);
  return Number.isSafeInteger(id) && id > 0 ? id : null;
}

function createFveHandlers(database) {
  async function iniciarProceso(req, res) {
    const idDiagnostico = parseId(req.body?.id_diagnostico);
    const idUsuario = parseId(req.user?.id_usuario);

    if (!idUsuario) {
      return res.status(401).json({ error: 'Usuario no autenticado' });
    }
    if (!idDiagnostico) {
      return res.status(400).json({ error: 'id_diagnostico debe ser un entero positivo' });
    }

    let client;
    let started = false;

    try {
      client = await database.connect();
      await client.query('BEGIN');
      started = true;

      const diagnosticoResult = await client.query(
        `SELECT d.id_diagnostico, d.id_mipyme, d.estado,
                m.estado AS estado_mipyme
           FROM public.diagnostico d
           JOIN public.mipyme m ON m.id_mipyme = d.id_mipyme
          WHERE d.id_diagnostico = $1`,
        [idDiagnostico]
      );

      if (diagnosticoResult.rowCount === 0) {
        await client.query('ROLLBACK');
        started = false;
        return res.status(404).json({ error: 'Diagnostico no encontrado' });
      }

      const d = diagnosticoResult.rows[0];
      if (d.estado !== 'activo' || d.estado_mipyme === 'eliminado') {
        await client.query('ROLLBACK');
        started = false;
        return res.status(422).json({
          error: 'El proceso FVE solo puede iniciarse desde un diagnostico activo de una empresa vigente'
        });
      }

      // UNIQUE(id_diagnostico) makes repeated clicks and concurrent requests safe.
      const insert = await client.query(
        `INSERT INTO public.fve_proceso
          (id_diagnostico, id_mipyme, created_by)
         VALUES ($1, $2, $3)
         ON CONFLICT (id_diagnostico) DO NOTHING
         RETURNING *`,
        [idDiagnostico, d.id_mipyme, idUsuario]
      );

      const creado = insert.rowCount > 0;
      let proceso = insert.rows[0];
      if (!creado) {
        const existente = await client.query(
          `SELECT * FROM public.fve_proceso
            WHERE id_diagnostico = $1`,
          [idDiagnostico]
        );
        proceso = existente.rows[0];
      } else {
        // Event and process are committed atomically.
        await client.query(
          `INSERT INTO public.audit_log
            (id_usuario_actor, accion, entidad, id_entidad,
             datos_nuevos, motivo, ip, user_agent)
           VALUES ($1, 'FVE_PROCESO_INICIADO', 'fve_proceso', $2,
                   $3::jsonb, 'Inicio de negociacion desde diagnostico',
                   $4, $5)`,
          [idUsuario, proceso.id_proceso,
           JSON.stringify({
             id_diagnostico: proceso.id_diagnostico,
             id_mipyme: proceso.id_mipyme,
             estado: proceso.estado,
             paso_actual: proceso.paso_actual
           }),
           req.ip || null, req.get?.('user-agent') || null]
        );
      }

      await client.query('COMMIT');
      started = false;
      return res.status(creado ? 201 : 200).json({
        message: creado ? 'Proceso FVE iniciado' : 'Proceso FVE existente recuperado',
        creado,
        proceso
      });
    } catch (error) {
      if (started) {
        try { await client.query('ROLLBACK'); } catch (_) { /* log original error */ }
      }
      console.error('Error al iniciar proceso FVE:', error);
      return res.status(500).json({ error: 'No fue posible iniciar el proceso FVE' });
    } finally {
      if (client) client.release();
    }
  }

  async function obtenerProceso(req, res) {
    const id = parseId(req.params?.idProceso);
    if (!id) {
      return res.status(400).json({ error: 'ID de proceso invalido' });
    }

    try {
      const result = await database.query(
        `SELECT p.*, d.titulo AS titulo_diagnostico,
                m.nombre_mipyme
           FROM public.fve_proceso p
           JOIN public.diagnostico d ON d.id_diagnostico = p.id_diagnostico
           JOIN public.mipyme m ON m.id_mipyme = p.id_mipyme
          WHERE p.id_proceso = $1`,
        [id]
      );
      if (result.rowCount === 0) {
        return res.status(404).json({ error: 'Proceso FVE no encontrado' });
      }
      return res.status(200).json({ proceso: result.rows[0] });
    } catch (error) {
      console.error('Error consultando proceso FVE:', error);
      return res.status(500).json({ error: 'No fue posible consultar el proceso FVE' });
    }
  }

  async function obtenerPorDiagnostico(req, res) {
    const id = parseId(req.params?.idDiagnostico);
    if (!id) {
      return res.status(400).json({ error: 'ID de diagnostico invalido' });
    }

    try {
      const result = await database.query(
        `SELECT p.*, d.titulo AS titulo_diagnostico,
                m.nombre_mipyme
           FROM public.fve_proceso p
           JOIN public.diagnostico d ON d.id_diagnostico = p.id_diagnostico
           JOIN public.mipyme m ON m.id_mipyme = p.id_mipyme
          WHERE p.id_diagnostico = $1`,
        [id]
      );
      return res.status(200).json({
        proceso: result.rows[0] || null
      });
    } catch (error) {
      console.error('Error consultando proceso FVE por diagnostico:', error);
      return res.status(500).json({ error: 'No fue posible consultar el proceso FVE' });
    }
  }

  return { iniciarProceso, obtenerProceso, obtenerPorDiagnostico };
}

module.exports = { createFveHandlers };
